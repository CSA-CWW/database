import getpass, tkinter
from tkinter import *
from tkinter import ttk

root = Tk()

def submit(): #submit command#
    file = open('File.txt','a')
    file.write ('Username: ' +str(uservar.get())+ ' | Password: ' +str(passvar.get())+ ' | Gender: ' +str(gendervar.get())+ ' | UserType: ' +str(typevar.get())+ '  | Option: ' +str(optvar.get())+ '\n')
def clear(): #clear command#
    uservar.set('')
    passvar.set('')
    gendervar.set('')
    typevar.set('')
    optvar.set('')


optvar = StringVar()
uservar = StringVar() 
passvar = StringVar() #variables#
typevar = StringVar()
gendervar = StringVar()

 
label_user = Label(root,text='Username:')
label_passw = Label(root,text='Password:')
label_type = Label(root,text='UserType:') # labels
label_gender = Label(root,text='Gender:')
label_opt = Label(root,text='Options:')


entry_user = ttk.Entry(root, textvariable=uservar, width=20)
entry_passw = ttk.Entry(root,show="*",textvariable=passvar, width=20) #username/password#


malRB = ttk.Radiobutton(root, text='Male', variable=gendervar,value='Male')
femaleRB = ttk.Radiobutton(root, text='Female', variable=gendervar, value='Female')
attackRB = ttk.Radiobutton(root, text='Attack Helicopter', variable=gendervar, value='Attack Helicopter') #gender#


admin = ttk.Checkbutton(root, text='Admin',onvalue='Admin', offvalue='no', variable=typevar)
user = ttk.Checkbutton(root, text='User',onvalue='User', offvalue='no', variable=typevar) #user type#
guest = ttk.Checkbutton(root, text='Guest',onvalue='Guest', offvalue='no', variable=typevar)


option = ttk.Combobox(root,state="readonly",textvariable = optvar)
option['values'] = ('IT', 'HR', 'Sales', 'Maintenance', 'Other') #option#


submit_b = Button(root, text='Submit', bg='Green', fg='white', command=submit, width=20, state=NORMAL) #submit and clear#
clear_b = Button(root, text='Clear', bg='Red', fg='white', command=clear, width=20)


label_user.pack(anchor=W)
entry_user.pack(anchor=W)
label_passw.pack(anchor=W)
entry_passw.pack(anchor=W)


label_gender.pack(anchor=W)
malRB.pack(anchor=W)
femaleRB.pack(anchor=W)
attackRB.pack(anchor=W)


label_type.pack(anchor=W)
admin.pack(anchor=W)            
user.pack(anchor=W)
guest.pack(anchor=W)                            #packed everything#


label_opt.pack(anchor=W)
option.pack(anchor=W)


submit_b.pack(anchor=W)
clear_b.pack(anchor=W)


root.title('Create User')

root.mainloop()
root.destroy()

#9 25 18#
#comp prog#
#cameron watts#
